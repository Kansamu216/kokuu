# Voidkit 品牌视觉包

> Zero-config intelligence.
> 定稿日期：2026-10-13 ｜ 本包为位图资产包（不含矢量源文件）

## 目录结构

```
voidkit-brand-kit/
├── logo/                        # 标志
│   ├── voidkit-logo-primary.png   主标志（图标 + 标准字，浅底用）
│   ├── voidkit-logo-mark.png      图标版（仅 VK 符号，浅底用）
│   └── voidkit-logo-inverse.png   暗色反白版（深底用）
├── icons/                       # 图标链
│   ├── icon.ico                   多尺寸 ico（16/32/48/64/128/256）
│   ├── icon.png                   256×256，可直接用作 Forge mod icon
│   └── icon-128 / -64 / -32 / -16.png
├── banners/
│   └── voidkit-banner-readme.png  README 头图（1280×720）
├── palette/
│   └── voidkit-palette.png        品牌色卡（1280×720）
└── showcase/                    # 应用展示图
    ├── showcase-1-studio.png      无菌影棚（1:1）
    ├── showcase-2-ui.png          容器化 UI（16:9）
    ├── showcase-3-swiss.png       瑞士平面（1:1）
    └── showcase-4-mist.png        晨雾光场（16:9）
```

## 标志说明

- **构成**：VK 组合字标，靛蓝方块落在 V 的负空间——「模块插进 kit」的隐喻
- **标准字**：Voidkit，粗几何无衬线，首字母大写
- **Slogan**：Zero-config intelligence.（含句点）

## 色彩体系

| 角色 | 色名 | 色值 | 用途 |
|------|------|------|------|
| 强调色 | Indigo 500 | `#4F46E5` | 唯一强调色：方块点缀、链接、主按钮 |
| 主文字/图形 | Slate 950 | `#0F172A` | 标志笔画、正文、图标主体 |
| 浅底 | Slate 50 | `#F8FAFC` | 页面/画布背景 |

规则：**一套物料只允许一个强调色**。禁止引入第二种彩色；灰阶可自由使用。

## 使用规范

1. **留白**：标志四周留白不小于标志高度的 25%。
2. **最小尺寸**：主标志（含字标）不小于 96px 宽；小于该尺寸一律改用图标版（icons/）。
3. **底色**：浅底用 primary / mark，深底（#0F172A 一类）用 inverse。禁止把浅底版直接压在照片或彩色底上。
4. **禁止**：拉伸变形、改变配色、加投影/描边/渐变、旋转、裁切负空间。
5. **Mod 实装**：将 `icons/icon.png` 复制到 mod 资源目录作为 mod 图标；网站 favicon 用 `icons/icon.ico`。

## 风格边界

浅色工具风（Grafana / Gitea / Linear 一派）：中性灰阶 + 单一靛蓝强调、细边框、克制圆角。
禁止：游戏化元素、深色矿物色、二次元风格、斜纹/斜面装饰。
